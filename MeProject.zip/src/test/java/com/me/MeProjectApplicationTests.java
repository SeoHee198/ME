package com.me;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MeProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
