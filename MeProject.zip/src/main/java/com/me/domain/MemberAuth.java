package com.me.domain;

import lombok.Data;

@Data
public class MemberAuth {

	private int userNo;
	private String auth;

}