package com.me.service;

import com.me.domain.Member;

public interface MemberService {
	// 회원가입
	public void register(Member member) throws Exception;

}
